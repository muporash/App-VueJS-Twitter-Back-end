<template>
  <div id="TweetsDefault">
    <div class="columns">
      
    </div>
  </div>
</template>

<script>
export default {
  name: 'tweetsDefault'
}
</script>
